"""Utility scripts package for diagnostics and maintenance helpers."""
