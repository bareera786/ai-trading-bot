"""Indicator calculation and management package."""

from .calculator import IncrementalIndicatorCalculator

__all__ = ["IncrementalIndicatorCalculator"]